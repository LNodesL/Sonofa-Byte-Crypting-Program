# Utils

Any needed tools to assist the build process.

## BTCH

Bytes to C++ Header for file includes is a tool that helps convert a PE into a bytes array for a header file (source/Hatchling.h).

More info: https://github.com/LNodesL/BytesToCppHeader
