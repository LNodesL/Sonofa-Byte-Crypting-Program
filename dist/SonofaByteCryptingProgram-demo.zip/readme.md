# SonofaByteCryptingProgram

Drag & drop any valid PE into SonofaByteCryptingProgram.exe in your file explorer to crypt the file. For testing, the helloworld.exe file has been provided to you.

A terminal window will appear with a log of information. Upon success, your original PE has been encrypted and is ready.

Press Enter to continue & close the terminal window. Hatchling.exe will be created for you, which is the final program. Opening this will also open your original PE that you dropped into SonofaByteCryptingProgram in the first step.

## Command Line Interface

You may use SonofaByteCryptingProgram CLI like so:

```
./SonofaByteCryptingProgram.exe helloworld.exe
```

This will create: ./Hatchling.exe
